const {deviceList} = require("./foxess");
deviceList();